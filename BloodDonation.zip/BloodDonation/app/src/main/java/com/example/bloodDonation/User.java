package com.example.bloodDonation;

public class User {
    private String Id;
    private String Name;
    private String Email;
    private String phoneno;
    private String pass;
    private String bg;

    public User(String id, String name, String email, String phoneno, String pass, String bg) {
        Id = id;
        Name = name;
        Email = email;
        this.phoneno = phoneno;
        this.pass = pass;
        this.bg = bg;
    }

    public String getId() {
        return Id;
    }

    public String getName() {
        return Name;
    }

    public String getEmail() {
        return Email;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public String getPass() {
        return pass;
    }

    public String getBg() {
        return bg;
    }
}
