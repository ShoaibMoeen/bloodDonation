package com.example.blooddonation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

public class signUp extends AppCompatActivity {
    EditText un,em,pass,phone,cpass;
    Button b;
    TextView l;
    String u=null,e=null,p=null,c=null,ph=null;
    FirebaseAuth mAuth;
    FirebaseFirestore db;
    CollectionReference cf;
    RadioGroup btype;
    RadioButton rb;
    ArrayAdapter<String> adapter;
    String[] bloodgroups={"A+","A-","B+","B-","AB+","AB-","O+","O-"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        un=findViewById(R.id.signupfullname);
        em=findViewById(R.id.usersignupemail);
        phone=findViewById(R.id.usersignupphone);
        pass=findViewById(R.id.usersignuppass);
        cpass=findViewById(R.id.usercfmpass);
        btype=findViewById(R.id.bg);
        b=findViewById(R.id.usersignupbtn);

        l=findViewById(R.id.loginBtnOnSignup);
        mAuth=FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();
        cf=db.collection("Users");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                u=un.getText().toString();
                e=em.getText().toString();
                p=pass.getText().toString();
                c=cpass.getText().toString();
                ph=phone.getText().toString();
                final int i=btype.getCheckedRadioButtonId();
                if(TextUtils.isEmpty(u))
                {
                    Toast.makeText(signUp.this,"Please Enter Name",Toast.LENGTH_LONG).show();
                    return;
                }
                if(TextUtils.isEmpty(e))
                {
                    Toast.makeText(signUp.this,"Please Enter Email",Toast.LENGTH_LONG).show();
                    return;
                }
                if(TextUtils.isEmpty(ph))
                {
                    Toast.makeText(signUp.this,"Please Enter Phone Number",Toast.LENGTH_LONG).show();
                    return;
                }
                if(TextUtils.isEmpty(p))
                {
                    Toast.makeText(signUp.this,"Please Enter password",Toast.LENGTH_LONG).show();
                    return;
                }
                if(p.length()<6)
                {
                    Toast.makeText(signUp.this,"Password too short",Toast.LENGTH_LONG).show();
                    return;
                }
                if(!p.equals(c))
                {
                    Toast.makeText(signUp.this,"Password and Confirm Password dont match",Toast.LENGTH_LONG).show();
                    return;
                }
                if(i==-1)
                {
                    Toast.makeText(signUp.this,"Please Select Blood Type",Toast.LENGTH_LONG).show();
                    return;
                }
                if(p.equals(c))
                {
                    mAuth.createUserWithEmailAndPassword(e, p)
                            .addOnCompleteListener(signUp.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        FirebaseUser user = mAuth.getCurrentUser();
                                        rb=findViewById(i);
                                        String bg=rb.getText().toString();
                                        User use=new User(user.getUid(),u,e,ph,p,bg);
                                        cf.document(user.getUid()).set(use);
                                        FirebaseMessaging.getInstance().subscribeToTopic(bg)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        Toast.makeText(getApplicationContext(),"Successfully Subscribed for notifications",Toast.LENGTH_LONG).show();
                                                    }
                                                });
                                        startActivity(new Intent(getApplicationContext(),HomePage.class));

                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Toast.makeText(signUp.this, "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();
                                    }

                                    // ...
                                }
                            });

                }
            }
        });
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });
    }
}
