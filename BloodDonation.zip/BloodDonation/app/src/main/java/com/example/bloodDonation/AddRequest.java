package com.example.bloodDonation;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class AddRequest extends AppCompatActivity {
    EditText n,p,d;
    String na,ph,des;
    Button b;
    RadioGroup rg;
    FirebaseFirestore db;
    FirebaseAuth mAuth;
    FirebaseUser firebaseUser;
    CollectionReference cf;
    RadioButton rb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_request);
        cf=FirebaseFirestore.getInstance().collection("BloodRequest");
        mAuth=FirebaseAuth.getInstance();
        n=findViewById(R.id.requestername);
        p=findViewById(R.id.requesterphone);
        d=findViewById(R.id.requesterdes);
        b=findViewById(R.id.reqbtn);
        rg=findViewById(R.id.reqbg);


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                na=n.getText().toString();
                 ph=p.getText().toString();
                 des=d.getText().toString();
                final int i=rg.getCheckedRadioButtonId();
                if(TextUtils.isEmpty(na)||TextUtils.isEmpty(ph))
                {
                    Toast.makeText(getApplicationContext(),"Name or Phone Number Missing",Toast.LENGTH_LONG).show();
                    return;
                }
                if(i==-1)
                {
                    Toast.makeText(getApplicationContext(),"Blood Type not selected",Toast.LENGTH_LONG).show();
                    return;
                }
                rb=findViewById(i);
                String a=rb.getText().toString();
                AlertDialog.Builder build=new AlertDialog.Builder(AddRequest.this);
                build.setCancelable(true);
                build.setTitle("Blood Request");
                build.setMessage("You want to request "+a+ " type blood for "+na);
                build.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                        String id=Long.toString(System.currentTimeMillis());
                        BloodRequest br=new BloodRequest(id,rb.getText().toString(),firebaseUser.getUid(),na,ph,des);
                        cf.document(id).set(br);
                        Intent returnIntent = new Intent();
                        returnIntent.putExtra("id",id);
                        returnIntent.putExtra("bg",rb.getText().toString());
                        returnIntent.putExtra("name",na);
                        returnIntent.putExtra("phone",ph);
                        returnIntent.putExtra("des",des);
                        setResult(Activity.RESULT_OK,returnIntent);
                        finish();

                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                build.show();

            }
        });


    }
}
