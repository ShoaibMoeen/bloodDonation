package com.example.bloodDonation;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class UserAdapter extends ArrayAdapter<User> {

    private Context mContext;
    private List<User> reqList = new ArrayList<>();

    public UserAdapter(@NonNull Context context, List<User> clist) {
        super(context, 0 , clist);
        mContext = context;
        reqList = clist;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.homelistitem,parent,false);

        User c = reqList.get(position);


        TextView bt = (TextView) listItem.findViewById(R.id.listitemBg);
        bt.setText(c.getBg());
        TextView n=listItem.findViewById(R.id.listItemname);
        String ss=c.getName();
        n.setText(c.getName());
        TextView p=listItem.findViewById(R.id.listItemPhone);
        p.setText(c.getPhoneno());


        return listItem;
    }
}