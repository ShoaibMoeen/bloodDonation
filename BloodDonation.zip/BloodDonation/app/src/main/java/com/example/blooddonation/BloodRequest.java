package com.example.blooddonation;

public class BloodRequest {
    private String reqid;
    private String bloodtype;
    private String requesterId;
    private String name;
    private String phone;
    private String description;

    public BloodRequest(String reqid,String bloodtype,String requesterid, String name, String phone, String description) {
        this.reqid=reqid;
        this.bloodtype = bloodtype;
        this.requesterId=requesterid;
        this.name = name;
        this.phone = phone;
        this.description = description;
    }

    public String getReqid() {
        return reqid;
    }

    public String getRequesterId() {
        return requesterId;
    }

    public String getBloodtype() {
        return bloodtype;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getDescription() {
        return description;
    }
}
