package com.example.bloodDonation;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<BloodRequest> {

    private Context mContext;
    private List<BloodRequest> reqList = new ArrayList<>();

    public CustomAdapter(@NonNull Context context, List<BloodRequest> clist) {
        super(context, 0 , clist);
        mContext = context;
        reqList = clist;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.homelistitem,parent,false);

        BloodRequest c = reqList.get(position);


        TextView bt = (TextView) listItem.findViewById(R.id.listitemBg);
        bt.setText(c.getBloodtype());
        TextView n=listItem.findViewById(R.id.listItemname);
        n.setText(c.getName());
        TextView p=listItem.findViewById(R.id.listItemPhone);
        p.setText(c.getPhone());


        return listItem;
    }
}