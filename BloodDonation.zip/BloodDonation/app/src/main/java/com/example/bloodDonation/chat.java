package com.example.bloodDonation;


import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;


public class chat extends AppCompatActivity {

    ImageView sendBtn;
    EditText sendmsg;
     FirebaseFirestore db = FirebaseFirestore.getInstance();
     CollectionReference cf = db.collection("Chat");
    FirebaseAuth AuthUI;
    MsgAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        sendBtn=findViewById(R.id.submit_button);
        sendmsg=findViewById(R.id.send_msg_text);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cf.document().set(new ChatMessage(sendmsg.getText().toString(),
                        FirebaseAuth.getInstance().getCurrentUser().getEmail()));
                sendmsg.setText("");
                sendmsg.requestFocus();
            }
        });
        setUpRecyclerView();


    }

    private void setUpRecyclerView() {
        Query query = cf.orderBy("messageTime", Query.Direction.DESCENDING);

        FirestoreRecyclerOptions<ChatMessage> options = new FirestoreRecyclerOptions.Builder<ChatMessage>()
                .setQuery(query, ChatMessage.class)
                .build();

        adapter = new MsgAdapter(options);

        RecyclerView recyclerView = findViewById(R.id.chatlist);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager lm=new LinearLayoutManager(this);
        lm.setReverseLayout(true);
        recyclerView.setLayoutManager(lm);

        recyclerView.setAdapter(adapter);
    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}