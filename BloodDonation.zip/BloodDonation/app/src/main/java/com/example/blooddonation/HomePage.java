package com.example.blooddonation;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class HomePage extends AppCompatActivity {
    FloatingActionButton fb;
    ListView bloodreq;
    FirebaseFirestore db;
    CollectionReference cf;
    FirebaseUser user;
    List<BloodRequest> l=new ArrayList<>();
    ArrayAdapter<BloodRequest> ra;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db=FirebaseFirestore.getInstance();
        cf=db.collection("BloodRequest");

        cf.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty())
                {
                    List<DocumentSnapshot> ds=queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d:ds)
                    {

                        String a=d.getString("reqid");
                        String b=d.getString("bloodtype");
                        String c=d.getString("requesterid");
                        String na=d.getString("name");
                        String ph=d.getString("phone");
                        String des=d.getString("description");
                        l.add(new BloodRequest(a,b,c,na,ph,des));
                    }
                    ra.notifyDataSetChanged();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
        setContentView(R.layout.activity_home_page);
        fb=findViewById(R.id.floating_action_button);
        bloodreq=findViewById(R.id.homelist);
        ra=new CustomAdapter(this,l);
        bloodreq.setAdapter(ra);
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(getApplicationContext(),AddRequest.class),1);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if(resultCode == Activity.RESULT_OK){
                user= FirebaseAuth.getInstance().getCurrentUser();
                String rb=data.getStringExtra("bg");
                String n=data.getStringExtra("name");
                String p=data.getStringExtra("phone");
                String id=data.getStringExtra("id");
                String des=data.getStringExtra("des");
                BloodRequest br=new BloodRequest(id,rb,user.getUid(),n,p,des);
                l.add(br);
                ra.notifyDataSetChanged();

            }
            else if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }
}
