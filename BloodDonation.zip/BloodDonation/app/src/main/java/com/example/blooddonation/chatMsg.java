package com.example.blooddonation;

public class chatMsg {

    private String senderid;
    private String recieverid;
    private Long Time;
    private String msg;

    public chatMsg(String senderid, String recieverid, Long time, String msg) {
        this.senderid = senderid;
        this.recieverid = recieverid;
        Time = time;
        this.msg = msg;
    }

    public String getSenderid() {
        return senderid;
    }

    public String getRecieverid() {
        return recieverid;
    }

    public Long getTime() {
        return Time;
    }

    public String getMsg() {
        return msg;
    }
}
