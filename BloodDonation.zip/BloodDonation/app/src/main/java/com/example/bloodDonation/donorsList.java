package com.example.bloodDonation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class donorsList extends AppCompatActivity {

    FirebaseFirestore db;
    CollectionReference cf;
    List<User> l=new ArrayList<>();
    ArrayAdapter<User> ra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donors_list);
        ListView lv=findViewById(R.id.donorlist);
        db=FirebaseFirestore.getInstance();
        ra=new UserAdapter(this,l);
        cf=db.collection("Users");
        cf.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty())
                {
                    List<DocumentSnapshot> ds=queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d:ds)
                    {

                        String a=d.getString("Id");
                        String b=d.getString("name");
                        String c=d.getString("Email");
                        String na=d.getString("phoneno");
                        String ph=d.getString("pass");
                        String des=d.getString("bg");
                        l.add(new User(a,b,c,na,ph,des));
                    }
                    ra.notifyDataSetChanged();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
        lv.setAdapter(ra);

    }
}
